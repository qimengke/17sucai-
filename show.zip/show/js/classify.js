//function _touch(){
//	var dom = document.getElementById('demo');
//	var _li=dom.getElementsByTagName('li');
//		for(var i=0;i<_li.length;i++){
//			/*绑定div touch事件*/
////			touch(dom,'tap',function() {
////				console.info('绑定点击touch事件成功');
////			});
////	
////			touch(dom,'left',function() {
////				console.info('触发事件,向左滑动');
////			})
////			touch(dom,'right',function() {
////				console.info('触发事件,向右滑动');
////			})
//			var _index=_li.index;
//			touch(_li[0],'tap',function() {
////				console.info('绑定点击touch事件成功');
//				_li[i].hide();
//				_li[_index].show();
//			});
//		}
//}
//_touch()
////$(function(){
////	$('#demo').find('li').each(function(){
////		
////		touch($(this).eq(0),'tap',function() {
////		//	console.info('绑定点击touch事件成功');
////		alert(1)
////		});
////	})
////})
//$(function(){
//	$("#fir").on("tap",function(){
//	alert(1)
//	$(this).hide();
//});
//})
