//$(function(){
//	$('#foot ul li').each(function(){
//		$(this).eq(0).click(function(){
//			location.href='index.html'
//		})
//		$(this).eq(1).find('span').click(function(){
//			location.href='../html/classify.html'
//		})
//	})
//})
