
	TouchSlide({
            slideCell:"#focus",
            titCell:".hd ul",
            mainCell:".bd ul",
            effect:"leftLoop",
            autoPlay:true,
            autoPage:true
    });


