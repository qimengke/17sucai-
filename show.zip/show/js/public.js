	var nWidth = document.documentElement.clientWidth;//设备的实际宽度

		var nFont = 100/(640/nWidth);

		document.getElementsByTagName('html')[0].style.fontSize = nFont+"px";